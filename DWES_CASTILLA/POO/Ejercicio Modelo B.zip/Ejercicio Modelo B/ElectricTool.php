<?php 

requires_once = 'Tool.php';

public class ElectricTool extends Tool{


public function __construct(
string $Sku, 
string $nombre, 
float $precioDia, 
string $descripcion,
string $potencia){
	parent::__construct($Sku,$nombre,$precioDia, $descripcion);
	
	
}


public function getPrecioDia(): float{
	
	
	
	return $this->precioDia * 1.25;
	
	
	
}


public function getPotencia(): string{
	
	
	
	return $this->potencia;
	
}






}


?>