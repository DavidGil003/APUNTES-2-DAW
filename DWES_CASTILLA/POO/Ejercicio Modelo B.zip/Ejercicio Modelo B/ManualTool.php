<?php   

requires_once = 'Tool.php';

public class ManualTool extends Tool{

public function getPrecioDia():float{
	
	
	
	return $this->precioDia;
	
	
}


}





?>