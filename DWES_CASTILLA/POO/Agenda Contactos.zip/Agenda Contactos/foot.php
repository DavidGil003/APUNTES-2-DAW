
<footer>
        <p><strong>Agenda de Contactos</strong> - Sistema de gestión simple y eficiente</p>
        <p style="margin-top: 10px; font-size: 0.9em;">
            💡 Tip: Marca tus contactos como favoritos haciendo clic en la estrella
        </p>
        <p style="margin-top: 5px; font-size: 0.85em; color: #999;">
            © <?php echo date('Y'); ?> - Desarrollado para gestión de contactos en jornadas de captación
        </p>
    </footer>
</body>
</html>