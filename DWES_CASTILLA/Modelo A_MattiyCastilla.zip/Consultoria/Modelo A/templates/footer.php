</div> <footer style="text-align: center; padding: 25px; color: #777; margin-top: 20px; border-top: 1px solid #eee;">
            <p>&copy; <?php echo date("Y"); ?> CRM Básico. Proyecto Modelo A.</p>
        </footer>

    </body>
</html>